<div class="copyrights">
	<p>&copy; 2018 OneSouree. All Rights Reserved </p>
</div>	