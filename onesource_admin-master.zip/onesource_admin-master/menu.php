<li id="dashboardId"><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>
<li id="registerUserId"><a href="registerUser.php"><i class="fa fa-user" aria-hidden="true"></i><span>Register User</span><div class="clearfix"></div></a></li>
<li id="viewUserId"><a href="viewUser.php"><i class="fa fa-table" aria-hidden="true"></i><span>View User</span><div class="clearfix"></div></a></li>
<li id="viewDetailId"><a href="viewDetails.php"><i class="fa fa-table" aria-hidden="true"></i><span>View Details</span><div class="clearfix"></div></a></li>
<li id="submitInquiryId"><a onclick="submitInquiry()" href="javascript:void(0)"><i class="fa fa-book" aria-hidden="true"></i><span>Submit Inquiry</span><div class="clearfix"></div></a></li>
