<?php 
//echo $_GET['file'];
// unlink('../../inquiry_demo/upload/pur_f2chk8772.jpg');
//echo $_GET['file'];
unlink($_GET['file']);
  //if( unlink($_GET['file'])){
//       if(1==2){
//       echo "Got Success";
//   }
//   else{
//       echo "Not Success";
//   }

  //header('Location: http://localhost/onesource_admin/dashboard.php')
?>